setwd("C:\\Users\\it24102276\\Desktop\\IT24102276")
branch_data <-read.csv("Exercise.txt",header=TRUE)
fix(branch_data)
attach(branch_data)
str(branch_data)
names(branch_data) <- c("Branch","Team Attendance","Team Salary","Years")
boxplot(Sales_X1,main="Box plot for Sales",outline=TRUE,outpch=8,horizontal=TRUE)
hist(Sales_X1,ylab = "Frequency",xlab = "Sales",main = "Histogram for Sales distribution ")
quantile(Advertising_X2)
IQR(Advertising_X2)


get.outliers <- function(z) {
  q1 <- quantile(z)[2]  
  q3 <- quantile(z)[4]  
  iqr <- q3 - q1      
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr  
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers: ", paste(sort(z[z < lb | z > ub]), collapse = ",")))
}



